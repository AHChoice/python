#include <iostream>
#include "string_constr.h"
#include "string_length.h"
#include "string_convert.h"
#include "string_assign.h"
#include "string_append.h"
#include "string_insert.h"
#include "string_replace.h"

int main()
{
	//cm_length::length();
	cm_string::constructor();
	cm_convert::getCharacter();
	cm_assign::assign();
	string_append::append();
	string_insert::insert();
	string_replace::replace();
	//
	return 0;
}