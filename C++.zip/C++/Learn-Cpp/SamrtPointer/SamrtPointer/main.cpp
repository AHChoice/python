#include <iostream>
#include "unique_ptr.h"
#include "weak_ptr.h"

int main()
{
	//cm_unique::get();
	cm_weak_ptr::weak();
	return 0;
}
