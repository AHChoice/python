// Operators.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Bitwise.h"
#include "BitFlagsMasks.h"
int _tmain(int argc, _TCHAR* argv[])
{

	//bitflag::bitset();
	//bitwise::BitWise();
	bitflag::RGB();
	return 0;
}

