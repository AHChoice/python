#include <iostream>
#include "open.h"

int main()
{
	open_cm::tie();
	return 0;
}