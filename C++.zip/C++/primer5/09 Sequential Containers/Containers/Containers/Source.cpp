#include <iostream>
using namespace std;
#include "Header.h"
int main()
{
    sampleuse();
    return 0;
}