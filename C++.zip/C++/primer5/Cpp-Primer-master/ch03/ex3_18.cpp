#include <vector>

int main()
{
    std::vector<int> ivec{ 42 };
    return 0;
}
