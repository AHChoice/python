// AHTemplate.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Header.h"

int main()
{
    smapleuse();
    return 0;
}

