#include <iostream>
using namespace std;

#include "Header.h"

int main()
{
    SampleUse();
    return 0;
}