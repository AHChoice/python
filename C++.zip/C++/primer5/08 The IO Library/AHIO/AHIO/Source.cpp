#include <iostream>
using namespace std;

#include "Header.h"

int main()
{
    //func_2();
   // func_4();
   // myinfo();
    readphone();
    return 0;
}